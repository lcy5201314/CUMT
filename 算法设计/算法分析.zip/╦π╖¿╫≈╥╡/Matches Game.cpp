#include<stdio.h>
#include<string.h>
#include<math.h>
#include<map>
#include<queue>
#include<set>
#include<stack>
#include<string>
#include<iostream>
#include<algorithm>
using namespace std;
#define inf 0x3f3f3f3f
int main()
{
    int n;
    while(~scanf("%d",&n))
    {
        int flag=0;
        long long x;
        for(int i=1;i<=n;i++)
        {
            scanf("%lld",&x);
            flag^=x;
        }
        if(flag)
       printf("Yes\n");
        else
        printf("No\n");
    }
    return 0;
}


