#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int orignal[24];
int New[24];
int Cmp[24];
int dp[24][24];
int main()
{
    int n;
    scanf("%d",&n);

    for(int i=1; i<=n; i++)
    {
        int a;
        scanf("%d",&a);
        orignal[a]=i;

    }
    while(~scanf("%d",&New[1]))
    {
        Cmp[New[1]]=1;
        for(int i=2; i<=n; i++)
        {
            scanf("%d",&New[i]);
            Cmp[New[i]]=i;
        }
        memset(dp,0,sizeof(dp));
        for(int i=2; i<=n+1; i++)
        {

            for(int j=2; j<=n+1; j++)
            {
                if(Cmp[i-1]==orignal[j-1])
                    dp[i][j]=dp[i-1][j-1]+1;
                else dp[i][j]=max(dp[i-1][j],dp[i][j-1]);
            }

        }
        cout<<dp[n+1][n+1]<<endl;

    }

    return 0;
}
